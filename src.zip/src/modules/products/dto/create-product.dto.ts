export class CreateProductDto {
  name: string;
  tags: string[];
}
