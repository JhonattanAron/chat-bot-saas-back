import { Controller } from '@nestjs/common';

@Controller('session')
export class SessionController {}
