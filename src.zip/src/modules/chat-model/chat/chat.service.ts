import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model, Types } from "mongoose";
import { PromptGeneratorService } from "../config/prompt-generator.service";
import { Chat, ChatDocument } from "../schemas/chat.schema";
import { PredictionService } from "../model-ai/predictions.service";
import { ProductsService } from "src/modules/products/products.service";
import { UsersService } from "src/modules/users/users.service";
import { FaqsService } from "src/modules/faqs/faqs.service";

@Injectable()
export class ChatService {
  constructor(
    @InjectModel(Chat.name) private chatModel: Model<ChatDocument>,
    private promptGen: PromptGeneratorService,
    private readonly predictionService: PredictionService,
    private readonly productSearchService: ProductsService,
    private readonly userService: UsersService,
    private readonly faqsService: FaqsService
  ) {}

  async createChat(userId: string, promt: string): Promise<ChatDocument> {
    let input_tokens = 0;
    let output_tokens = 0;
    const context = await this.userService.getAssistantChatByUserId(userId);

    if (!context) {
      throw new Error(`No context found for userId ${userId}`);
    }

    // Prompt inicial
    const prompt = this.promptGen.generateInitialPromt(
      context.name,
      context.description,
      "",
      promt
    );

    // Primera predicción
    const prediction = await this.predictionService.predict(prompt);
    const firstResponse = prediction.output;
    input_tokens += prediction.input_tokens;
    output_tokens += prediction.output_tokens;

    // Extraer funciones a ejecutar y ejecutarlas
    let faqInfo = "";
    let productosString = "";
    const faqMatch = firstResponse.match(/\[FAQ:(.*?)\]/i);
    if (faqMatch) {
      const faqQuery = faqMatch[1].trim();
      const faqResults = await this.faqsService.search(
        faqQuery,
        userId,
        context._id?.toString() ?? ""
      );
      if (faqResults && faqResults.length > 0) {
        faqInfo = faqResults[0].answer;
      }
    }
    const searchMatch = firstResponse.match(/\[SEARCH:(.*?)\]/i);
    if (searchMatch) {
      const searchTerm = searchMatch[1].trim();
      const relatedProducts = await this.productSearchService.search(
        searchTerm,
        userId
      );
      if (relatedProducts.length === 0) {
        productosString = "No se encontraron productos con ese término.";
      } else {
        productosString = relatedProducts.map((p) => p.name).join(", ");
      }
    }

    // Extraer IMPORTANT_INFO
    const importantInfoMatch = firstResponse.match(
      /\[IMPORTANT_INFO:([^\]]+)\]/
    );
    const importantInfo = importantInfoMatch
      ? importantInfoMatch[1].trim()
      : "";

    // Prompt final para el modelo, pasando FAQ y productos como contexto
    const finalPrompt = this.promptGen.generateMessagePromt(
      importantInfo,
      faqInfo,
      productosString,
      "",
      promt
    );

    // Segunda predicción con toda la info relevante
    const finalPrediction = await this.predictionService.predict(finalPrompt);
    let finalMessage = finalPrediction.output;

    // Limpiar etiquetas de funciones pendientes en el mensaje final
    finalMessage = finalMessage
      .replace(/\[FAQ:.*?\]/gi, "")
      .replace(/\[SEARCH:.*?\]/gi, "")
      .replace(/\[FUNCTIONS:.*?\]/gi, "")
      .trim();

    // Construir el campo important_info final
    const funcionesEjecutadas: string[] = [];
    if (faqMatch) funcionesEjecutadas.push(`[FAQ:${faqMatch[1].trim()}]`);
    if (searchMatch)
      funcionesEjecutadas.push(`[SEARCH:${searchMatch[1].trim()}]`);
    const importantInfoFinal = `[IMPORTANT_INFO: ${importantInfo}${
      funcionesEjecutadas.length
        ? ` [FUNCIONES_EJECUTADAS: ${funcionesEjecutadas.join(" ")}]`
        : ""
    }]`;

    // Guardar solo mensajes válidos (user y assistant)
    const messages = [
      {
        role: "user",
        content: promt,
        createdAt: new Date(),
      },
      {
        role: "assistant",
        content: finalMessage,
        createdAt: new Date(),
        important_info: importantInfoFinal,
      },
    ];

    const chat = new this.chatModel({
      userId,
      chatId: new Types.ObjectId().toHexString(),
      prompt,
      messages,
      lastActivityAt: new Date(),
      input_tokens,
      output_tokens,
    });

    return chat.save();
  }
  private async extractAndSearchProducts(response: string, userId: string) {
    const match = response.match(/\[SEARCH:(.*?)\]/i);
    if (!match) return null;
    const searchTerm = match[1].trim();
    return this.productSearchService.search(searchTerm, userId);
  }
  async addMessage(
    chatId: string,
    role: "user" | "assistant",
    content: string
  ) {
    const chat = await this.chatModel.findOne({
      $or: [{ chatId }, { _id: chatId }],
    });
    if (!chat) throw new Error(`Chat with chatId ${chatId} not found`);

    if (role === "user") {
      // Guardar el mensaje del usuario
      await this.chatModel.findOneAndUpdate(
        { $or: [{ chatId }, { _id: chatId }] },
        {
          $push: { messages: { role, content, createdAt: new Date() } },
          $set: { lastActivityAt: new Date() },
        }
      );

      // Obtener el important_info del último mensaje assistant (si existe)
      const lastAssistantMsg = [...chat.messages]
        .reverse()
        .find((m) => m.role === "assistant");
      let prevImportantInfo = lastAssistantMsg?.important_info || "";

      // Bucle para ejecutar funciones hasta que no haya ninguna pendiente
      let promptContent = content;
      let faqInfo = "";
      let productosString = "";
      let importantInfo = "";
      let funcionesEjecutadas: string[] = [];
      let finalMessage = "";
      let maxLoops = 3; // Evita bucles infinitos

      do {
        const prompt = this.promptGen.generateMessagePromt(
          importantInfo,
          faqInfo,
          productosString,
          "",
          promptContent
        );
        const prediction = await this.predictionService.predict(prompt);
        finalMessage = prediction.output;

        // Extraer funciones a ejecutar
        faqInfo = "";
        productosString = "";
        funcionesEjecutadas = [];

        const faqMatch = finalMessage.match(/\[FAQ:(.*?)\]/i);
        if (faqMatch) {
          const faqQuery = faqMatch[1].trim();
          funcionesEjecutadas.push(`[FAQ:${faqQuery}]`);
          const faqResults = await this.faqsService.search(
            faqQuery,
            chat.userId,
            chat._id?.toString() ?? ""
          );
          if (faqResults && faqResults.length > 0) {
            faqInfo = faqResults[0].answer;
          }
        }

        const searchMatch = finalMessage.match(/\[SEARCH:(.*?)\]/i);
        if (searchMatch) {
          const searchTerm = searchMatch[1].trim();
          funcionesEjecutadas.push(`[SEARCH:${searchTerm}]`);
          const relatedProducts = await this.productSearchService.search(
            searchTerm,
            chat.userId
          );
          if (relatedProducts.length === 0) {
            productosString = "No se encontraron productos con ese término.";
          } else {
            productosString = relatedProducts.map((p) => p.name).join(", ");
          }
        }

        // Extraer IMPORTANT_INFO
        const importantInfoMatch = finalMessage.match(
          /\[IMPORTANT_INFO:([^\]]+)\]/
        );
        importantInfo = importantInfoMatch ? importantInfoMatch[1].trim() : "";

        // Limpiar etiquetas de funciones pendientes en el mensaje final
        finalMessage = finalMessage
          .replace(/\[FAQ:.*?\]/gi, "")
          .replace(/\[SEARCH:.*?\]/gi, "")
          .replace(/\[FUNCTIONS:.*?\]/gi, "")
          .trim();

        maxLoops--;
        // Si todavía hay funciones, el ciclo se repite
      } while (
        (/\[FAQ:.*?\]/i.test(finalMessage) ||
          /\[SEARCH:.*?\]/i.test(finalMessage)) &&
        maxLoops > 0
      );

      // Construir el campo important_info final
      const importantInfoFinal = `[IMPORTANT_INFO: ${importantInfo}${
        funcionesEjecutadas.length
          ? ` [FUNCIONES_EJECUTADAS: ${funcionesEjecutadas.join(" ")}]`
          : ""
      }]`;

      // Guardar la respuesta del asistente con el nuevo important_info
      await this.chatModel.findOneAndUpdate(
        { $or: [{ chatId }, { _id: chatId }] },
        {
          $push: {
            messages: {
              role: "assistant",
              content: finalMessage,
              createdAt: new Date(),
              important_info: importantInfoFinal,
            },
          },
          $set: { lastActivityAt: new Date() },
        }
      );
    }

    return this.chatModel.findOne({ $or: [{ chatId }, { _id: chatId }] });
  }

  async getChat(chatId: string) {
    return this.chatModel.findOne({ chatId });
  }
}
